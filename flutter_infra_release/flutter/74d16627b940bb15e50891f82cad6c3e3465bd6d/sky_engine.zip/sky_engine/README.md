Flutter Engine
==============

This package describes the dart:ui library, which is the interface between
Dart and the Flutter Engine. This package also contains a number of Flutter
shell binaries that let you run code that uses the dart:ui library on various
platforms.
