# _android_symbols_license_md

This bundle is part of the the Flutter SDK.

The source code is hosted at [flutter/engine/shell/platform/android](https://github.com/flutter/engine/tree/4d491573ecabc8648bd3a742d7e4d9df29731984/shell/platform/android).
The license for this bundle is hosted at [flutter/engine/sky/packages/sky_engine/LICENSE](https://github.com/flutter/engine/tree/4d491573ecabc8648bd3a742d7e4d9df29731984/sky/packages/sky_engine/LICENSE) 
and [sky_engine.zip](https://storage.googleapis.com/flutter_infra_release/flutter/4d491573ecabc8648bd3a742d7e4d9df29731984/sky_engine.zip).
